package com.services;

import java.util.List;

import com.dto.ItemDto;
import com.entities.Item;

public interface ItemService {
	public List<ItemDto> getItems();
}
